"""
Canadian Vehicle Database - Complete Trim Levels
Upload to Replit Database

This script loads Canadian vehicle data with ALL trim levels
into Replit's Key-Value database.
"""

import csv
import json
from replit import db
from collections import defaultdict

def load_canadian_vehicles_to_replit(filename='canadian_vehicles_all_trims.csv'):
    """
    Load Canadian vehicle CSV with all trims into Replit database
    CSV format: year, make, model, trim
    """
    vehicles_by_year = defaultdict(list)
    
    print("📊 Loading Canadian Vehicle Data to Replit...")
    print("=" * 70)
    
    # Read CSV file
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            row_count = 0
            
            for row in reader:
                year = row.get('year')
                make = row.get('make')
                model = row.get('model')
                trim = row.get('trim', 'Standard')
                
                if year and make and model:
                    vehicles_by_year[year].append({
                        'make': make,
                        'model': model,
                        'trim': trim
                    })
                    row_count += 1
        
        print(f"✓ Read {row_count} vehicle records from CSV\n")
        
    except FileNotFoundError:
        print(f"❌ Error: Could not find {filename}")
        print("Please upload the CSV file to your Replit project")
        return False
    
    # Store in Replit database
    total_vehicles = 0
    for year in sorted(vehicles_by_year.keys()):
        vehicles = vehicles_by_year[year]
        # Store as JSON string
        db[f"vehicles_{year}"] = json.dumps(vehicles)
        total_vehicles += len(vehicles)
        print(f"  ✓ Year {year}: {len(vehicles)} vehicles stored")
    
    print(f"\n{'=' * 70}")
    print(f"✓ SUCCESS! Loaded {total_vehicles} vehicles total")
    print(f"✓ Stored in {len(vehicles_by_year)} year groups")
    print(f"{'=' * 70}\n")
    
    return True

def get_vehicles_by_year(year):
    """Get all vehicles for a specific year"""
    data = db.get(f"vehicles_{year}")
    if data:
        return json.loads(data)
    return []

def get_vehicles_by_make(make):
    """Get all vehicles for a specific make (all years)"""
    result = []
    for key in db.keys():
        if key.startswith("vehicles_"):
            vehicles = json.loads(db[key])
            for vehicle in vehicles:
                if vehicle['make'].lower() == make.lower():
                    result.append(vehicle)
    return result

def get_vehicles_by_make_model(make, model):
    """Get all trims for a specific make/model (all years)"""
    result = []
    for key in db.keys():
        if key.startswith("vehicles_"):
            year = key.replace("vehicles_", "")
            vehicles = json.loads(db[key])
            for vehicle in vehicles:
                if (vehicle['make'].lower() == make.lower() and 
                    vehicle['model'].lower() == model.lower()):
                    result.append({
                        'year': year,
                        'trim': vehicle['trim']
                    })
    return result

def get_all_years():
    """Get list of all available years"""
    years = []
    for key in db.keys():
        if key.startswith("vehicles_"):
            year = key.replace("vehicles_", "")
            years.append(year)
    return sorted(years, reverse=True)

def get_all_makes():
    """Get list of all unique makes"""
    makes = set()
    for key in db.keys():
        if key.startswith("vehicles_"):
            vehicles = json.loads(db[key])
            for vehicle in vehicles:
                makes.add(vehicle['make'])
    return sorted(makes)

def search_vehicles(year=None, make=None, model=None, trim=None):
    """
    Advanced search for vehicles
    All parameters optional - use to filter
    """
    results = []
    for key in db.keys():
        if key.startswith("vehicles_"):
            current_year = key.replace("vehicles_", "")
            vehicles = json.loads(db[key])
            
            for vehicle in vehicles:
                # Apply filters
                if year and current_year != str(year):
                    continue
                if make and vehicle['make'].lower() != make.lower():
                    continue
                if model and vehicle['model'].lower() != model.lower():
                    continue
                if trim and vehicle['trim'].lower() != trim.lower():
                    continue
                
                # Add year to result
                vehicle['year'] = current_year
                results.append(vehicle)
    
    return results

# MAIN EXECUTION
if __name__ == "__main__":
    print("\n" + "🚗" * 35)
    print("CANADIAN VEHICLE DATABASE - REPLIT LOADER")
    print("🚗" * 35 + "\n")
    
    # Load the data
    success = load_canadian_vehicles_to_replit('canadian_vehicles_all_trims.csv')
    
    if success:
        print("QUERY EXAMPLES:")
        print("=" * 70)
        
        # Example 1: Get 2024 vehicles
        print("\n1️⃣  Get all 2024 vehicles:")
        print("   vehicles_2024 = get_vehicles_by_year('2024')")
        vehicles_2024 = get_vehicles_by_year('2024')
        if vehicles_2024:
            print(f"   Found {len(vehicles_2024)} vehicles")
            print(f"   Sample: {vehicles_2024[0]}")
        
        # Example 2: Get all Honda vehicles
        print("\n2️⃣  Get all Honda vehicles (all years):")
        print("   honda_cars = get_vehicles_by_make('Honda')")
        honda = get_vehicles_by_make('Honda')
        if honda:
            print(f"   Found {len(honda)} Honda vehicles")
            print(f"   Sample: {honda[0]}")
        
        # Example 3: Get all Honda CR-V trims
        print("\n3️⃣  Get all CR-V trims by year:")
        print("   crv_trims = get_vehicles_by_make_model('Honda', 'CR-V')")
        crv = get_vehicles_by_make_model('Honda', 'CR-V')
        if crv:
            print(f"   Found {len(crv)} CR-V variants")
            for item in crv[:3]:
                print(f"      - {item['year']} {item['trim']}")
        
        # Example 4: Get all years
        print("\n4️⃣  Get all available years:")
        print("   years = get_all_years()")
        years = get_all_years()
        print(f"   Years: {years}")
        
        # Example 5: Get all makes
        print("\n5️⃣  Get all makes (manufacturers):")
        print("   makes = get_all_makes()")
        makes = get_all_makes()
        print(f"   Total makes: {len(makes)}")
        print(f"   Sample: {makes[:5]}")
        
        # Example 6: Advanced search
        print("\n6️⃣  Search for specific vehicles:")
        print("   results = search_vehicles(year='2024', make='Toyota')")
        toyota_2024 = search_vehicles(year='2024', make='Toyota')
        if toyota_2024:
            print(f"   Found {len(toyota_2024)} Toyota vehicles for 2024")
            for v in toyota_2024[:3]:
                print(f"      - {v['model']} {v['trim']}")
        
        print("\n" + "=" * 70)
        print("✅ Database ready! Use the functions above to query data")
        print("=" * 70 + "\n")
    else:
        print("\n❌ Failed to load database")
