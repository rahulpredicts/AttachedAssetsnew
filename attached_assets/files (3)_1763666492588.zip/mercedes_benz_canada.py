mercedes_benz_canada = {
    "brand": "Mercedes-Benz",
    "market": "Canada",
    "last_updated": "2025-11-20",
    "models": {
        "sedans": [
            {
                "name": "C-Class",
                "category": "Compact Luxury Sedan",
                "trims": [
                    "C 300 4MATIC",
                    "AMG C 43 4MATIC"
                ]
            },
            {
                "name": "E-Class",
                "category": "Mid-Size Luxury Sedan",
                "trims": [
                    "E 350 4MATIC",
                    "E 450 4MATIC",
                    "AMG E 53 HYBRID"
                ]
            },
            {
                "name": "S-Class",
                "category": "Full-Size Luxury Sedan",
                "trims": [
                    "S 500 4MATIC LWB",
                    "S 580 4MATIC LWB",
                    "AMG S 63 E PERFORMANCE"
                ]
            },
            {
                "name": "Mercedes-Maybach S-Class",
                "category": "Ultra-Luxury Sedan",
                "trims": [
                    "S 580 4MATIC",
                    "S 680 4MATIC"
                ]
            },
            {
                "name": "EQE",
                "category": "Electric Mid-Size Sedan",
                "trims": [
                    "EQE 350 4MATIC",
                    "EQE 500 4MATIC",
                    "AMG EQE 4MATIC+"
                ]
            },
            {
                "name": "EQS",
                "category": "Electric Full-Size Luxury Sedan",
                "trims": [
                    "EQS 450 4MATIC",
                    "EQS 580 4MATIC",
                    "AMG EQS 4MATIC+"
                ]
            }
        ],
        "wagons": [
            {
                "name": "E-Class Wagon",
                "category": "Mid-Size Luxury Wagon",
                "trims": [
                    "E 350 4MATIC",
                    "E 450 4MATIC",
                    "AMG E 53 HYBRID"
                ]
            }
        ],
        "coupes": [
            {
                "name": "CLA Coupe",
                "category": "Compact Luxury Coupe",
                "trims": [
                    "CLA 250 4MATIC",
                    "AMG CLA 35 4MATIC",
                    "AMG CLA 45 S 4MATIC+"
                ]
            },
            {
                "name": "C-Class Coupe",
                "category": "Compact Luxury Coupe",
                "trims": [
                    "C 300 4MATIC",
                    "AMG C 43 4MATIC"
                ]
            }
        ],
        "suvs": [
            {
                "name": "GLA",
                "category": "Compact SUV",
                "passenger_capacity": 5,
                "trims": [
                    "GLA 250 4MATIC",
                    "AMG GLA 35 4MATIC"
                ]
            },
            {
                "name": "GLB",
                "category": "Compact SUV (7-seat option)",
                "passenger_capacity": "5 (7 optional)",
                "trims": [
                    "GLB 250 4MATIC",
                    "AMG GLB 35 4MATIC"
                ]
            },
            {
                "name": "GLC",
                "category": "Mid-Size SUV",
                "passenger_capacity": 5,
                "trims": [
                    "GLC 300 4MATIC",
                    "GLC 350e 4MATIC (Hybrid)",
                    "AMG GLC 43",
                    "AMG GLC 63 S E PERFORMANCE"
                ]
            },
            {
                "name": "GLC Coupe",
                "category": "Mid-Size Coupe SUV",
                "passenger_capacity": 5,
                "trims": [
                    "GLC 300 4MATIC",
                    "AMG GLC 43 4MATIC",
                    "AMG GLC 63 S E PERFORMANCE"
                ]
            },
            {
                "name": "GLE",
                "category": "Full-Size SUV",
                "passenger_capacity": 5,
                "trims": [
                    "GLE 350 4MATIC",
                    "GLE 450 4MATIC",
                    "GLE 450e 4MATIC (Hybrid)",
                    "AMG GLE 53 4MATIC+",
                    "AMG GLE 63 S 4MATIC+"
                ]
            },
            {
                "name": "GLE Coupe",
                "category": "Full-Size Coupe SUV",
                "passenger_capacity": 5,
                "trims": [
                    "GLE 450 4MATIC",
                    "AMG GLE 53 4MATIC+",
                    "AMG GLE 63 S 4MATIC+"
                ]
            },
            {
                "name": "GLS",
                "category": "3-Row Full-Size SUV",
                "passenger_capacity": 7,
                "trims": [
                    "GLS 450 4MATIC",
                    "GLS 580 4MATIC",
                    "AMG GLS variants"
                ]
            },
            {
                "name": "G-Class",
                "category": "Off-Road Icon SUV",
                "trims": [
                    "AMG G 63 4MATIC"
                ]
            },
            {
                "name": "EQB",
                "category": "Electric Compact SUV",
                "trims": [
                    "EQB 300 4MATIC",
                    "EQB 500 4MATIC"
                ]
            },
            {
                "name": "EQE SUV",
                "category": "Electric Mid-Size SUV",
                "passenger_capacity": 5,
                "trims": [
                    "EQE 350 4MATIC",
                    "EQE 500 4MATIC",
                    "AMG EQE"
                ]
            },
            {
                "name": "EQS SUV",
                "category": "Electric Full-Size SUV",
                "trims": [
                    "EQS 450 4MATIC",
                    "EQS 500 4MATIC",
                    "AMG EQS 4MATIC+"
                ]
            },
            {
                "name": "Mercedes-Maybach EQS SUV",
                "category": "Electric Ultra-Luxury SUV",
                "trims": [
                    "Mercedes-Maybach EQS 680 4MATIC"
                ]
            },
            {
                "name": "Mercedes-Maybach GLS",
                "category": "Ultra-Luxury 3-Row SUV",
                "passenger_capacity": 7,
                "trims": [
                    "GLS 600 4MATIC"
                ]
            }
        ]
    },
    "body_styles": [
        "Sedan",
        "Wagon",
        "Coupe",
        "SUV",
        "Coupe SUV",
        "Cabriolet/Roadster"
    ],
    "powertrains": [
        "Turbocharged Gasoline",
        "Hybrid (Gasoline + Electric)",
        "Plug-in Hybrid Electric Vehicle (PHEV)",
        "Battery Electric Vehicle (BEV)"
    ],
    "drivetrain_options": [
        "4MATIC (All-Wheel Drive)",
        "RWD (Rear-Wheel Drive)"
    ]
}

# Helper functions to work with the data
def get_all_sedans():
    return mercedes_benz_canada["models"]["sedans"]

def get_all_suvs():
    return mercedes_benz_canada["models"]["suvs"]

def get_all_coupes():
    return mercedes_benz_canada["models"]["coupes"]

def get_all_wagons():
    return mercedes_benz_canada["models"]["wagons"]

def get_model_by_name(name):
    for category in mercedes_benz_canada["models"].values():
        for model in category:
            if model["name"].lower() == name.lower():
                return model
    return None

def get_all_models():
    all_models = []
    for category in mercedes_benz_canada["models"].values():
        all_models.extend(category)
    return all_models

def get_total_model_count():
    count = 0
    for category in mercedes_benz_canada["models"].values():
        count += len(category)
    return count

def get_all_trims_for_model(model_name):
    model = get_model_by_name(model_name)
    if model and "trims" in model:
        return model["trims"]
    return None

# Example usage:
if __name__ == "__main__":
    print(f"Total Mercedes-Benz Models in Canada: {get_total_model_count()}")
    print(f"\nAll Sedans: {len(get_all_sedans())}")
    print(f"All Wagons: {len(get_all_wagons())}")
    print(f"All Coupes: {len(get_all_coupes())}")
    print(f"All SUVs: {len(get_all_suvs())}")
    
    # Get C-Class trims
    c_class_trims = get_all_trims_for_model("C-Class")
    print(f"\nC-Class Trims: {c_class_trims}")
