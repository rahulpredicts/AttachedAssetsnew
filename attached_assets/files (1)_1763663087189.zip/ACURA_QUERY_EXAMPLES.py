"""
ACURA DATABASE - REPLIT QUERY EXAMPLES
Complete Python code examples for working with Acura vehicle data
"""

import csv
import json
from replit import db
from collections import defaultdict

# ═══════════════════════════════════════════════════════════════════════════
# LOADER FUNCTION - Run this first
# ═══════════════════════════════════════════════════════════════════════════

def load_acura_database(filename='ACURA_ALL_MODELS_TRIMS_YEARWISE.csv'):
    """Load Acura database into Replit"""
    vehicles_by_year = defaultdict(list)
    
    print("🚗 Loading ACURA DATABASE...")
    print("=" * 70)
    
    with open(filename, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        count = 0
        
        for row in reader:
            year = row.get('year')
            make = row.get('make')
            model = row.get('model')
            trim = row.get('trim')
            
            if year and model and trim:
                vehicles_by_year[year].append({
                    'model': model,
                    'trim': trim
                })
                count += 1
    
    # Store in database
    for year in sorted(vehicles_by_year.keys()):
        db[f"acura_{year}"] = json.dumps(vehicles_by_year[year])
        print(f"  ✓ {year}: {len(vehicles_by_year[year])} trims stored")
    
    print("=" * 70)
    print(f"✅ LOADED {count} ACURA TRIMS TOTAL\n")


# ═══════════════════════════════════════════════════════════════════════════
# QUERY FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════

def get_acura_year(year):
    """Get all Acura vehicles for a specific year"""
    data = db.get(f"acura_{year}")
    return json.loads(data) if data else []

def get_acura_model_all_years(model_name):
    """Get all trims of a model across all years"""
    results = defaultdict(list)
    for key in db.keys():
        if key.startswith("acura_"):
            year = key.replace("acura_", "")
            vehicles = json.loads(db[key])
            for vehicle in vehicles:
                if vehicle['model'].lower() == model_name.lower():
                    results[year].append(vehicle['trim'])
    return dict(results)

def get_acura_model_year(model_name, year):
    """Get specific model for specific year"""
    vehicles = get_acura_year(year)
    return [v['trim'] for v in vehicles if v['model'].lower() == model_name.lower()]

def get_all_acura_models():
    """Get list of all unique Acura models"""
    models = set()
    for key in db.keys():
        if key.startswith("acura_"):
            vehicles = json.loads(db[key])
            for vehicle in vehicles:
                models.add(vehicle['model'])
    return sorted(models)

def get_all_acura_years():
    """Get list of all years"""
    years = []
    for key in db.keys():
        if key.startswith("acura_"):
            year = key.replace("acura_", "")
            years.append(year)
    return sorted(years, reverse=True)


# ═══════════════════════════════════════════════════════════════════════════
# EXAMPLE QUERIES
# ═══════════════════════════════════════════════════════════════════════════

print("\n" + "🚗" * 35)
print("ACURA DATABASE QUERY EXAMPLES")
print("🚗" * 35 + "\n")

# First, load the data
load_acura_database('ACURA_ALL_MODELS_TRIMS_YEARWISE.csv')


# ═══════════════════════════════════════════════════════════════════════════
# EXAMPLE 1: Get all Acura models for 2024
# ═══════════════════════════════════════════════════════════════════════════

print("\n1️⃣  ALL 2024 ACURA MODELS & TRIMS")
print("-" * 70)

acura_2024 = get_acura_year('2024')
print(f"Total 2024 Acura trims: {len(acura_2024)}\n")

# Group by model
models_2024 = defaultdict(list)
for vehicle in acura_2024:
    models_2024[vehicle['model']].append(vehicle['trim'])

for model in sorted(models_2024.keys()):
    trims = models_2024[model]
    print(f"  {model}:")
    for trim in trims:
        print(f"    └─ {trim}")


# ═══════════════════════════════════════════════════════════════════════════
# EXAMPLE 2: Show RDX evolution (all years)
# ═══════════════════════════════════════════════════════════════════════════

print("\n2️⃣  ACURA RDX - EVOLUTION (2011-2024)")
print("-" * 70)

rdx_history = get_acura_model_all_years('RDX')

for year in sorted(rdx_history.keys(), reverse=True):
    trims = rdx_history[year]
    print(f"  {year}: {', '.join(trims)}")


# ═══════════════════════════════════════════════════════════════════════════
# EXAMPLE 3: Show MDX trim evolution
# ═══════════════════════════════════════════════════════════════════════════

print("\n3️⃣  ACURA MDX - TRIM PROGRESSION")
print("-" * 70)

mdx_history = get_acura_model_all_years('MDX')

for year in sorted(mdx_history.keys(), reverse=True):
    trims = mdx_history[year]
    num_trims = len(trims)
    print(f"  {year}: {num_trims} trims ({', '.join(trims)})")


# ═══════════════════════════════════════════════════════════════════════════
# EXAMPLE 4: Compare models across years
# ═══════════════════════════════════════════════════════════════════════════

print("\n4️⃣  ACURA LINEUP COMPARISON - LAST 3 YEARS")
print("-" * 70)

for year in ['2024', '2023', '2022']:
    vehicles = get_acura_year(year)
    models = defaultdict(int)
    
    for vehicle in vehicles:
        models[vehicle['model']] += 1
    
    print(f"\n  {year} ({len(vehicles)} total trims):")
    for model in sorted(models.keys()):
        print(f"    {model}: {models[model]} trims")


# ═══════════════════════════════════════════════════════════════════════════
# EXAMPLE 5: Get trims for specific model/year
# ═══════════════════════════════════════════════════════════════════════════

print("\n5️⃣  2024 ACURA TLX - ALL AVAILABLE TRIMS")
print("-" * 70)

tlx_2024_trims = get_acura_model_year('TLX', '2024')
print(f"  Available TLX trims for 2024:")
for i, trim in enumerate(tlx_2024_trims, 1):
    print(f"    {i}. {trim}")


# ═══════════════════════════════════════════════════════════════════════════
# EXAMPLE 6: Find all A-Spec models
# ═══════════════════════════════════════════════════════════════════════════

print("\n6️⃣  ALL ACURA A-SPEC MODELS (2024)")
print("-" * 70)

acura_2024 = get_acura_year('2024')
aspec_vehicles = [v for v in acura_2024 if 'A-Spec' in v['trim']]

print(f"  A-Spec trims available in 2024: {len(aspec_vehicles)}")
for vehicle in aspec_vehicles:
    print(f"    {vehicle['model']}: {vehicle['trim']}")


# ═══════════════════════════════════════════════════════════════════════════
# EXAMPLE 7: Timeline - Show when models were introduced
# ═══════════════════════════════════════════════════════════════════════════

print("\n7️⃣  ACURA MODEL INTRODUCTION TIMELINE")
print("-" * 70)

all_models = get_all_acura_models()
all_years = sorted(get_all_acura_years())

for model in all_models:
    history = get_acura_model_all_years(model)
    first_year = min(history.keys())
    last_year = max(history.keys())
    
    if first_year == last_year:
        status = f"{first_year} only"
    elif int(last_year) == 2024:
        status = f"{first_year}-{last_year} (CURRENT)"
    else:
        status = f"{first_year}-{last_year} (DISCONTINUED)"
    
    print(f"  {model:10} {status}")


# ═══════════════════════════════════════════════════════════════════════════
# EXAMPLE 8: Statistical analysis
# ═══════════════════════════════════════════════════════════════════════════

print("\n8️⃣  ACURA DATABASE STATISTICS")
print("-" * 70)

all_years = sorted(get_all_acura_years(), reverse=True)
total_records = 0
models_count = defaultdict(int)

for year in all_years:
    vehicles = get_acura_year(year)
    total_records += len(vehicles)
    
    for vehicle in vehicles:
        models_count[vehicle['model']] += 1

print(f"\n  Total Records: {total_records}")
print(f"  Total Models: {len(models_count)}")
print(f"  Years Covered: {min(all_years)}-{max(all_years)}")

print(f"\n  Trim Count by Model:")
for model in sorted(models_count.keys()):
    print(f"    {model}: {models_count[model]} total trims")

print(f"\n  Average Trims per Year:")
avg_per_year = total_records / len(all_years)
print(f"    {avg_per_year:.1f} trims/year")


# ═══════════════════════════════════════════════════════════════════════════
# EXAMPLE 9: Export to JSON
# ═══════════════════════════════════════════════════════════════════════════

print("\n9️⃣  EXPORT ACURA DATA TO JSON")
print("-" * 70)

all_acura_data = {}
for year in sorted(get_all_acura_years()):
    all_acura_data[year] = get_acura_year(year)

# Save to file
with open('acura_database.json', 'w') as f:
    json.dump(all_acura_data, f, indent=2)

print(f"  ✓ Exported to acura_database.json")
print(f"  File size: {len(json.dumps(all_acura_data))} bytes")


# ═══════════════════════════════════════════════════════════════════════════
# EXAMPLE 10: Create a simple lookup function
# ═══════════════════════════════════════════════════════════════════════════

print("\n🔟 ADVANCED LOOKUP FUNCTION")
print("-" * 70)

def search_acura(model=None, year=None, trim_contains=None):
    """Advanced search with filters"""
    results = []
    
    for key in db.keys():
        if key.startswith("acura_"):
            current_year = key.replace("acura_", "")
            vehicles = json.loads(db[key])
            
            for vehicle in vehicles:
                # Apply filters
                if year and current_year != str(year):
                    continue
                if model and vehicle['model'].lower() != model.lower():
                    continue
                if trim_contains and trim_contains.lower() not in vehicle['trim'].lower():
                    continue
                
                results.append({
                    'year': current_year,
                    'model': vehicle['model'],
                    'trim': vehicle['trim']
                })
    
    return results

# Test the search function
print("\n  Search 1: All A-Spec trims")
aspec_search = search_acura(trim_contains='A-Spec')
print(f"    Found {len(aspec_search)} A-Spec variants")

print("\n  Search 2: 2023 TLX models")
tlx_2023 = search_acura(year='2023', model='TLX')
print(f"    Found {len(tlx_2023)} 2023 TLX trims:")
for result in tlx_2023:
    print(f"      - {result['trim']}")

print("\n  Search 3: RDX across all years")
rdx_all = search_acura(model='RDX')
print(f"    Found {len(rdx_all)} RDX variants across {len(set(r['year'] for r in rdx_all))}")


# ═══════════════════════════════════════════════════════════════════════════
# FINAL SUMMARY
# ═══════════════════════════════════════════════════════════════════════════

print("\n" + "=" * 70)
print("✅ ACURA DATABASE IS READY!")
print("=" * 70)
print("\nYou can now:")
print("  • Query vehicles by year, model, or trim")
print("  • Export data to JSON/CSV")
print("  • Build applications on top of this database")
print("  • Search and filter Acura inventory")
print("\nUse the functions above to create your own queries!")
print("=" * 70 + "\n")
